/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package demoshop2;

import java.util.ArrayList;

/**
 *
 * @author ASUS
 */
public class Usuario {
    private String mNombre;
    private String mPass;
    private String mCorreoElectronico;
    private ArrayList<String> mListaRoles = new ArrayList();


    /**
     * @return the mNombre
     */
    public String getNombre() {
        return mNombre;
    }

    /**
     * @param mNombre the mNombre to set
     */
    public void setNombre(String mNombre) {
        this.mNombre = mNombre;
    }

    /**
     * @return the mPass
     */
    public String getPass() {
        return mPass;
    }

    /**
     * @param mPass the mPass to set
     */
    public void setPass(String mPass) {
        this.mPass = mPass;
    }

    /**
     * @return the mCorreoElectronico
     */
    public String getCorreoElectronico() {
        return mCorreoElectronico;
    }

    /**
     * @param mCorreoElectronico the mCorreoElectronico to set
     */
    public void setCorreoElectronico(String mCorreoElectronico) {
        this.mCorreoElectronico = mCorreoElectronico;
    }

    /**
     * @return the mListaRoles
     */
    public ArrayList<String> getListaRoles() {
        return mListaRoles;
    }

    /**
     * @param pListaRoles the mListaRoles to set
     */
    public void setListaRoles(ArrayList<String> pListaRoles) {
        this.mListaRoles = pListaRoles;
    }

}
